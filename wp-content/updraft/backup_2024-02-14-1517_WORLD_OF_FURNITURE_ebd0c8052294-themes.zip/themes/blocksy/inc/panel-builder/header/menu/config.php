<?php

$config = [
	'name' => __('Menu 1', 'blocksy'),
	'typography_keys' => ['headerMenuFont', 'headerDropdownFont'],
	'devices' => ['desktop'],
	'selective_refresh' => ['menu'],
	'excluded_from' => ['offcanvas']
];
