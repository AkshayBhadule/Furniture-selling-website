<?php

$config = [
	'name' => __('Trending Posts', 'blc'),
	'description' => __('Display a trending list of posts, products or custom post types at the bottom of your website.', 'blc')
];
