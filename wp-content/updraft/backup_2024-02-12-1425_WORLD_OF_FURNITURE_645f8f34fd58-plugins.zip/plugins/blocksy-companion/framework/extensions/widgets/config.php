<?php

$config = [
	'description' => __('Popular/Recent Posts, Advertisement, Contact Info, Mailchimp Subscribe, Social Icons and more.', 'blc')
];
