<?php

$config = [
	'name' => __('Product Reviews', 'blc'),
	'description' => __('A custom post type specially designed for creating product reviews.', 'blc'),
	'require_refresh' => true

	// 'hidden' => true
];



