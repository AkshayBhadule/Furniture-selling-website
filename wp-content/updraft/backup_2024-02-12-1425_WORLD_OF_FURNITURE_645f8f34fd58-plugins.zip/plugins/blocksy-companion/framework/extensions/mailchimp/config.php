<?php

$config = [
	'name' => __('Mailchimp Subscribe', 'blc'),
	'description' => __('Display a subscribe form with the help of a widget or a block.', 'blc')
];

