<?php

$config = [
	'name' => __('Cookies Consent', 'blc'),
	'description' => __('Enable this extension in order to comply with the GDPR regulations.', 'blc')
];
