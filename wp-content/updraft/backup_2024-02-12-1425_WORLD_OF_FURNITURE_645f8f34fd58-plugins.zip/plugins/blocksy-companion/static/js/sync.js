import '../../framework/features/header/items/account/sync'
import './sync/header'
