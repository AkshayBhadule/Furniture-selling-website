const DashboardContext = window.ctDashboardLocalizations.DashboardContext

export const Provider = DashboardContext.Provider
export const Consumer = DashboardContext.Consumer

export default DashboardContext
